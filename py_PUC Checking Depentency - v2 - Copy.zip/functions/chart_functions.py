from PyQt6.QtWidgets import QWidget, QVBoxLayout, QTabWidget, QFileDialog
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from ui.custom_widgets import HoverButton
import os

class ChartWindow(QWidget):
    def __init__(self, grouped_data, all_equipments):
        super().__init__()
        self.setWindowTitle('Charts of PIDs Focus at PUC Machine')
        self.showFullScreen()
        self.grouped_data = grouped_data
        self.all_equipments = all_equipments
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)

        self.create_charts_in_tabs()

        close_button = HoverButton("Close")
        close_button.clicked.connect(self.close)
        layout.addWidget(close_button)

    def create_charts_in_tabs(self):
        for group_name, data in self.grouped_data.items():
            equipment_list = sorted(data.keys())
            counts = [data[eq] for eq in equipment_list]
            total_ids = sum(counts)

            if total_ids == 0:
                continue  # Skip creating a tab if there's no data

            tab = QWidget()
            tab_layout = QVBoxLayout(tab)

            fig, ax = plt.subplots(figsize=(12, 6))
            bars = ax.bar(equipment_list, counts, color='#3498db')

            for bar, count in zip(bars, counts):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), str(count), 
                        ha='center', va='bottom', color='#2c3e50', fontsize=10)

            ax.set_xlabel('Equipment Number', fontsize=12, color='#2c3e50')
            ax.set_ylabel('Count of PIDs', fontsize=12, color='#2c3e50')
            ax.set_title(f'PIDs Focus at the PUC Machine ({group_name})\nTotal IDs: {total_ids}', fontsize=14, color='#2c3e50')
            ax.set_xticklabels(equipment_list, rotation=45, ha='right', color='#2c3e50')
            ax.tick_params(axis='both', colors='#2c3e50')
            
            ax.set_facecolor('#f8f9fa')
            fig.patch.set_facecolor('#f0f0f0')

            for spine in ax.spines.values():
                spine.set_edgecolor('#bdc3c7')

            for bar in bars:
                bar.set_color('#3498db')
                bar.set_edgecolor('#2980b9')
                bar.set_linewidth(1.5)

            fig.tight_layout()

            canvas = FigureCanvas(fig)
            tab_layout.addWidget(canvas)

            export_button = HoverButton('Export Chart')
            export_button.clicked.connect(lambda _, f=fig, g=group_name: self.export_chart(f, g))
            tab_layout.addWidget(export_button)

            self.tab_widget.addTab(tab, group_name)

    def export_chart(self, fig, group_name):
        Output_dir = 'Output'
        if not os.path.exists(Output_dir):
            os.makedirs(Output_dir)
        file_path, _ = QFileDialog.getSaveFileName(self, 'Save Chart', 
                                                   os.path.join(Output_dir, f'{group_name}.png'),
                                                   'PNG Files (*.png)')
        if file_path:
            fig.savefig(file_path)
            print(f'Chart saved as {file_path}')
