# Import các thư viện cần thiết
import sys
import os
import pandas as pd
from datetime import datetime, timedelta
import shutil
import time
import glob
from PyQt6.QtWidgets import QMessageBox

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def copy_logs_mono(start_date, end_date, selected_lines, log_callback=None):
    csv_path = os.path.join(script_dir, 'IP_List_PUC.csv')
    df = pd.read_csv(csv_path, index_col=None, sep=',', header=0)
    
    if selected_lines:
        df = df[df['MONO'].str.contains('|'.join(selected_lines))]
    
    pc_info = [(str(row['MONO']), str(row['IP1'])) for index, row in df.iterrows()]

    inaccessible_machines = []

    current_date = start_date
    while current_date <= end_date:
        date_str = current_date.strftime('%Y%m%d')

        for name, ip in pc_info:
            src_dir = f'\\\\{ip}\\c\\VH_PUC\\Logs\\{date_str}'
            dest_dir = os.path.join(script_dir, 'Input_1stPUC_Logs', name)

            if not os.path.exists(dest_dir):
                os.makedirs(dest_dir)

            try:
                files_copied = False
                for filename in os.listdir(src_dir):
                    if filename.startswith(date_str) and filename.endswith('.csv'):
                        src_file = os.path.join(src_dir, filename)
                        dest_file = os.path.join(dest_dir, filename)
                        if os.path.exists(dest_file):
                            new_filename = f'{filename[:-4]}_{int(time.time())}.csv'
                            dest_file = os.path.join(dest_dir, new_filename)
                        shutil.copy2(src_file, dest_file)
                        if log_callback:
                            log_callback(f"Copied: {dest_file}")
                        files_copied = True
                
                if not files_copied:
                    if log_callback:
                        log_callback(f"No files found for {name}\\{ip} on {date_str}")
            except (FileNotFoundError, PermissionError):
                inaccessible_machines.append(f'{name}\\{ip}')
                if log_callback:
                    log_callback(f"Unable to access machine {name}\\{ip}")
            except Exception as e:
                if log_callback:
                    log_callback(f"Error occurred while accessing {name}\\{ip}: {str(e)}")

        current_date += timedelta(days=1)

    if inaccessible_machines:
        message = 'Inaccessible machines:\n' + '\n'.join(inaccessible_machines)
        if log_callback:
            log_callback(message)
        QMessageBox.warning(None, 'Warning', message)
    else:
        if log_callback:
            log_callback('All machines were accessible.')
        QMessageBox.information(None, 'Success', 'All machines were accessible.')

def copy_logs_color(start_date, end_date, selected_lines, log_callback=None):
    csv_path = os.path.join(script_dir, 'IP_List_PUC.csv')
    df = pd.read_csv(csv_path, index_col=None, sep=',', header=0)
    
    if selected_lines:
        df = df[df['COLOR'].str.contains('|'.join(selected_lines))]
    
    pc_info = [(str(row['COLOR']), str(row['IP2'])) for index, row in df.iterrows()]

    inaccessible_machines = []

    current_date = start_date
    while current_date <= end_date:
        date_str = current_date.strftime('%Y%m%d')

        for name, ip in pc_info:
            src_dir = f'\\\\{ip}\\c\\VH_PUC\\Logs\\{date_str}'
            dest_dir = os.path.join(script_dir, 'Input_2ndPUC_Logs', name)

            if not os.path.exists(dest_dir):
                os.makedirs(dest_dir)

            try:
                files_copied = False
                for filename in os.listdir(src_dir):
                    if filename.startswith(date_str) and filename.endswith('.csv'):
                        src_file = os.path.join(src_dir, filename)
                        dest_file = os.path.join(dest_dir, filename)
                        if os.path.exists(dest_file):
                            new_filename = f'{filename[:-4]}_{int(time.time())}.csv'
                            dest_file = os.path.join(dest_dir, new_filename)
                        shutil.copy2(src_file, dest_file)
                        if log_callback:
                            log_callback(f"Copied: {dest_file}")
                        files_copied = True
                
                if not files_copied:
                    if log_callback:
                        log_callback(f"No files found for {name}\\{ip} on {date_str}")
            except (FileNotFoundError, PermissionError):
                inaccessible_machines.append(f'{name}\\{ip}')
                if log_callback:
                    log_callback(f"Unable to access machine {name}\\{ip}")
            except Exception as e:
                if log_callback:
                    log_callback(f"Error occurred while accessing {name}\\{ip}: {str(e)}")

        current_date += timedelta(days=1)

    if inaccessible_machines:
        message = 'Inaccessible machines:\n' + '\n'.join(inaccessible_machines)
        if log_callback:
            log_callback(message)
        QMessageBox.warning(None, 'Warning', message)
    else:
        if log_callback:
            log_callback('All machines were accessible.')
        QMessageBox.information(None, 'Success', 'All machines were accessible.')

def get_search_keys_from_template():
    try:
        df = pd.read_csv("Template_PUC.csv", nrows=1, header=2)
        return list(df.columns)
    except Exception as e:
        print(f"Error reading Template_PUC.csv: {e}")
        return []

def simplify1(log_callback=None):
    current_dir = os.getcwd()
    search_keys = get_search_keys_from_template()

    if not search_keys:
        if log_callback:
            log_callback("Error: Could not read column names from Template_PUC.csv")
        return

    input_dir_name = "Input_1stPUC_Logs"
    output_dir_name = "Output"
    file_ext = 'csv'

    if log_callback:
        log_callback(f"Using {len(search_keys)} columns from Template_PUC.csv")

    cwd = os.path.abspath('')
    output_dir = os.path.join(cwd, output_dir_name)
    input_dir = os.path.join(cwd, input_dir_name)
    os.chdir(input_dir)

    all_filenames = [i for i in glob.glob('**/*.{}'.format(file_ext), recursive=True)]

    if len(all_filenames) == 0:
        if log_callback:
            log_callback("Found no matched file in 'Input' folder")
            log_callback("Program exit now")
        return

    total_df = []
    output_file_num = 0

    for file in all_filenames:
        if log_callback:
            log_callback(f"Reading file: {file}")

        imported_df = pd.read_csv(file, index_col=None, sep=',', header=2, skipinitialspace=True, usecols=lambda x: x in search_keys)
        total_df.append(imported_df)
        output_file_num += 1

    merged_df = pd.concat(total_df, axis=0, ignore_index=True)

    # Add Short_SN column
    if log_callback:
        log_callback('Adding Short_SN column...')
    merged_df.insert(loc=0, column='Short_SN', value=merged_df['BARCODE'].str.slice(0, 22))

    # Filter out rows where FAILED_MSG is "PCHK_FAIL"
    if 'FAILED_MSG' in merged_df.columns:
        if log_callback:
            log_callback('Removing rows with PCHK_FAIL in FAILED_MSG column...')
        merged_df = merged_df[merged_df['FAILED_MSG'] != 'PCHK_FAIL']

    # Ask user for data selection preference
    reply = QMessageBox.question(None, 'Data Selection', 
                                 'Do you want to keep only the latest data for each Short_SN?',
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, 
                                 QMessageBox.StandardButton.Yes)

    if reply == QMessageBox.StandardButton.Yes:
        if log_callback:
            log_callback('Keeping only the latest data for each Short_SN...')
        merged_df = merged_df.sort_values(by=['Short_SN', 'DATE_TIME', 'STOP_TIME'], ascending=[True, False, False])
        merged_df_without_duplicates = merged_df.drop_duplicates(subset=['Short_SN'])
        output_df = merged_df_without_duplicates
    else:
        if log_callback:
            log_callback('Keeping all data...')
        output_df = merged_df

    output_df.to_csv(os.path.join(output_dir, f"1stPUC merged {output_file_num} files data.csv"), 
                     header=True, index=False, sep=",")
    
    if log_callback:
        log_callback("Export simplified csv file successfully")
        log_callback("Program finished here")

    QMessageBox.information(None, "Success", "Simplified csv file PUC successfully")
    os.chdir(current_dir)

def simplify2(log_callback=None):
    current_dir = os.getcwd()
    search_keys = get_search_keys_from_template()

    if not search_keys:
        if log_callback:
            log_callback("Error: Could not read column names from Template_PUC.csv")
        return

    input_dir_name = "Input_2ndPUC_Logs"
    output_dir_name = "Output"
    file_ext = 'csv'

    if log_callback:
        log_callback(f"Using {len(search_keys)} columns from Template_PUC.csv")

    cwd = os.path.abspath('')
    output_dir = os.path.join(cwd, output_dir_name)
    input_dir = os.path.join(cwd, input_dir_name)
    os.chdir(input_dir)

    all_filenames = [i for i in glob.glob('**/*.{}'.format(file_ext), recursive=True)]

    if len(all_filenames) == 0:
        if log_callback:
            log_callback("Found no matched file in 'Input' folder")
            log_callback("Program exit now")
        return

    total_df = []
    output_file_num = 0

    for file in all_filenames:
        if log_callback:
            log_callback(f"Reading file: {file}")

        imported_df = pd.read_csv(file, index_col=None, sep=',', header=2, skipinitialspace=True, usecols=lambda x: x in search_keys)
        total_df.append(imported_df)
        output_file_num += 1

    merged_df = pd.concat(total_df, axis=0, ignore_index=True)

    # Add Short_SN column
    if log_callback:
        log_callback('Adding Short_SN column...')
    merged_df.insert(loc=0, column='Short_SN', value=merged_df['BARCODE'].str.slice(0, 22))

    # Filter out rows where FAILED_MSG is "PCHK_FAIL"
    if 'FAILED_MSG' in merged_df.columns:
        if log_callback:
            log_callback('Removing rows with PCHK_FAIL in FAILED_MSG column...')
        merged_df = merged_df[merged_df['FAILED_MSG'] != 'PCHK_FAIL']

    # Ask user for data selection preference
    reply = QMessageBox.question(None, 'Data Selection', 
                                 'Do you want to keep only the latest data for each Short_SN?',
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, 
                                 QMessageBox.StandardButton.Yes)

    if reply == QMessageBox.StandardButton.Yes:
        if log_callback:
            log_callback('Keeping only the latest data for each Short_SN...')
        merged_df = merged_df.sort_values(by=['Short_SN', 'DATE_TIME', 'STOP_TIME'], ascending=[True, False, False])
        merged_df_without_duplicates = merged_df.drop_duplicates(subset=['Short_SN'])
        output_df = merged_df_without_duplicates
    else:
        if log_callback:
            log_callback('Keeping all data...')
        output_df = merged_df

    output_df.to_csv(os.path.join(output_dir, f"2ndPUC merged {output_file_num} files data.csv"), 
                     header=True, index=False, sep=",")
    
    if log_callback:
        log_callback("Export simplified csv file successfully")
        log_callback("Program finished here")

    QMessageBox.information(None, "Success", "Simplified csv file PUC successfully")
    os.chdir(current_dir)
