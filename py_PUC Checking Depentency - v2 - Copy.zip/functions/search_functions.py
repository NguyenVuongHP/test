import pandas as pd
from collections import Counter
import os
import glob
from PyQt6.QtWidgets import QMessageBox

equipment_groups = {
    '501 1stPUC': 'H9AMAL517',
    '501 2ndPUC': 'H9AMAL519',
    '502 1stPUC': 'H9AMAL527',
    '502 2ndPUC': 'H9AMAL529',
    '503 1stPUC': 'H9AMAL537',
    '503 2ndPUC': 'H9AMAL539',
    '504 1stPUC': 'H9AMAL547',
    '504 2ndPUC': 'H9AMAL549'
}

def find_csv_files(directory='Output'):
    return [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith('.csv')]

def search_pids(input_ids, csv_file_paths, log_callback=None):
    if not csv_file_paths:
        QMessageBox.information(None, 'No Data', 'No CSV file found in the Output')
        if log_callback:
            log_callback("Search failed: No CSV files found.")
        return None, None
    
    if log_callback:
        log_callback(f"Found {len(csv_file_paths)} CSV files.")
    
    dfs = [pd.read_csv(file) for file in csv_file_paths]
    df = pd.concat(dfs, ignore_index=True)
    
    if log_callback:
        log_callback(f"Total rows in combined dataframe: {len(df)}")
    
    df['PID'] = df['PID'].astype(str)
    df['Short_SN'] = df['Short_SN'].astype(str)
    df['EQUIPMENT_CHANNEL_INFO'] = df['EQUIPMENT_CHANNEL_INFO'].astype(str)
    df["EQUIPMENT_NUMBER_INFO"] = df['EQUIPMENT_NUMBER_INFO'].astype(str)
    df['EQP'] = df['EQUIPMENT_NUMBER_INFO'] + '_' + df['EQUIPMENT_CHANNEL_INFO']

    if log_callback:
        log_callback(f"Input IDs: {input_ids}")
    
    selected_counts = Counter()

    for input_id in input_ids:
        if len(input_id) == 15:
            equipment_info = df[df['PID'] == input_id]['EQP'].values
        elif len(input_id) == 22:
            equipment_info = df[df['Short_SN'] == input_id]['EQP'].values
        else:
            if log_callback:
                log_callback(f"Skipping invalid ID: {input_id}")
            continue
        
        for eq in equipment_info:
            selected_counts[eq] += 1

    if log_callback:
        log_callback(f"Selected counts: {dict(selected_counts)}")

    grouped_data = {group_name: {} for group_name in equipment_groups}

    all_equipments = list(df['EQP'].unique())  # Chuyển đổi thành list
    if log_callback:
        log_callback(f"All equipments: {all_equipments}")

    for equipment in all_equipments:
        for group_name, keyword in equipment_groups.items():
            if keyword in equipment:
                grouped_data[group_name][equipment] = selected_counts[equipment]
                break

    if log_callback:
        log_callback(f"Grouped data: {grouped_data}")
        log_callback("Search completed. Charts created.")

    return grouped_data, all_equipments
