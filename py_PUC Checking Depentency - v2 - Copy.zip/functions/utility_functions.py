import os
import shutil
from PyQt6.QtWidgets import QMessageBox, QFileDialog, QDialog, QVBoxLayout, QCheckBox, QPushButton
import pandas as pd
import glob

class ClearDataDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Clear Data')
        layout = QVBoxLayout(self)
        
        self.checkboxes = {}
        for folder in ['Input_1stPUC_logs', 'Input_2ndPUC_logs', 'Output']:
            self.checkboxes[folder] = QCheckBox(f"Clear {folder}")
            layout.addWidget(self.checkboxes[folder])
        
        clear_button = QPushButton('Clear Selected')
        clear_button.clicked.connect(self.accept)
        layout.addWidget(clear_button)
        
        cancel_button = QPushButton('Cancel')
        cancel_button.clicked.connect(self.reject)
        layout.addWidget(cancel_button)

def clear_data(log_callback=None):
    if log_callback:
        log_callback("Preparing to clear data...")
    
    dialog = ClearDataDialog()
    result = dialog.exec()
    
    if result == QDialog.DialogCode.Accepted:
        selected_folders = [folder for folder, checkbox in dialog.checkboxes.items() if checkbox.isChecked()]
        
        if selected_folders:
            if log_callback:
                log_callback("Clearing data...")
            
            for dir_name in selected_folders:
                dir_path = os.path.join(os.getcwd(), dir_name)
                if os.path.exists(dir_path):
                    for filename in os.listdir(dir_path):
                        file_path = os.path.join(dir_path, filename)
                        try:
                            if os.path.isfile(file_path) or os.path.islink(file_path):
                                os.unlink(file_path)
                            elif os.path.isdir(file_path):
                                shutil.rmtree(file_path)
                        except Exception as e:
                            if log_callback:
                                log_callback(f"Error clearing {file_path}: {e}")
                    if log_callback:
                        log_callback(f"All data cleared from {dir_name} folder.")
                else:
                    if log_callback:
                        log_callback(f"{dir_name} folder does not exist.")
            
            if log_callback:
                log_callback("Data clearing completed.")
            QMessageBox.information(None, 'Success', 'Selected data has been cleared successfully.')
        else:
            if log_callback:
                log_callback("No folders selected for clearing.")
    else:
        if log_callback:
            log_callback("Data clearing cancelled by user.")

def export_csv(text_input, log_callback=None):
    try:
        output_dir = 'Output'
        all_files = glob.glob(os.path.join(output_dir, "*.csv"))
        combined_csv = pd.concat([pd.read_csv(f) for f in all_files], ignore_index=True)

        ids_to_search = text_input.strip().split()

        result_df = combined_csv[combined_csv['PID'].isin(ids_to_search)]

        found_ids_count = result_df['PID'].nunique()

        output_filename = f"found_{found_ids_count}PID_SW_information.csv"

        output_file = os.path.join(output_dir, output_filename)
        result_df.to_csv(output_file, index=False)

        if log_callback:
            log_callback(f'Found {found_ids_count} out of {len(ids_to_search)} IDs.')
            log_callback(f'CSV file has been exported successfully to {output_file}')
        QMessageBox.information(None, 'Export Complete', 
                                f'Found {found_ids_count} out of {len(ids_to_search)} IDs.\n'
                                f'CSV file has been exported successfully to {output_file}')
    except Exception as e:
        if log_callback:
            log_callback(f'An error occurred while exporting CSV: {str(e)}')
        QMessageBox.critical(None, 'Error', f'An error occurred while exporting CSV: {str(e)}')

def open_output_folder():
    output_dir = os.path.join(os.getcwd(), 'Output')
    if os.path.exists(output_dir):
        os.startfile(output_dir)
    else:
        QMessageBox.warning(None, 'Folder Not Found', 'The Output folder does not exist.')
