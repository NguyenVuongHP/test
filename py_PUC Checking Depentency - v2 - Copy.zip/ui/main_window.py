from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QFrame, QGridLayout, QCheckBox, QMessageBox, QApplication
from PyQt6.QtCore import Qt, QDate, QSize
from PyQt6.QtGui import QScreen, QIcon
from ui.custom_widgets import HoverButton, GrayHoverButton
from ui.custom_calendar import CustomCalendar
from functions.log_functions import copy_logs_mono, copy_logs_color, simplify1, simplify2
from functions.search_functions import find_csv_files, search_pids
from functions.chart_functions import ChartWindow
from functions.utility_functions import clear_data, export_csv, open_output_folder
from datetime import datetime
import sys
import os

# Thêm đường dẫn của thư mục chứa rc_icons.py vào sys.path
rc_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'rc')
sys.path.append(rc_path)

# Import rc_icons
try:
    import rc_icons
except ImportError:
    print(f"Warning: rc_icons module not found in {rc_path}. Icons may not be displayed correctly.")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PUC Checking EQP Dependency")
        self.setGeometry(0, 0, 1400, 700)
        self.setup_ui()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        content_layout = QHBoxLayout()

        left_frame = QFrame()
        left_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 10px;
                margin: 10px;
            }
        """)
        left_layout = QVBoxLayout(left_frame)
        right_frame = QFrame()
        right_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 10px;
                margin: 10px;
            }
        """)
        right_layout = QVBoxLayout(right_frame)

        calendar_layout = QGridLayout()
        self.cal_start = CustomCalendar()
        self.cal_end = CustomCalendar()
        self.cal_start.selectionChanged.connect(self.update_start_date)
        self.cal_end.selectionChanged.connect(self.update_end_date)
        calendar_layout.addWidget(QLabel("Select Start Date:"), 0, 0)
        calendar_layout.addWidget(self.cal_start, 1, 0)
        calendar_layout.addWidget(QLabel("Select End Date:"), 0, 1)
        calendar_layout.addWidget(self.cal_end, 1, 1)
        left_layout.addLayout(calendar_layout)

        self.line_checkboxes = {}
        checkbox_layout = QHBoxLayout()
        for line in ['501 Line', '502 Line', '503 Line', '504 Line']:
            checkbox = QCheckBox(line)
            checkbox.stateChanged.connect(self.update_button_states)
            self.line_checkboxes[line] = checkbox
            checkbox_layout.addWidget(checkbox)
        left_layout.addLayout(checkbox_layout)

        icon_size = QSize(28, 28)  # Đặt kích thước icon mong muốn

        self.btn_copy_mono = GrayHoverButton("Loading 1stPUC Data")
        self.btn_copy_mono.setIcon(QIcon(":/icons/loading.png"))
        self.btn_copy_mono.setIconSize(icon_size)
        self.btn_copy_mono.clicked.connect(self.copy_logs_mono)
        self.btn_copy_mono.setEnabled(False)

        self.btn_copy_color = HoverButton("Loading 2ndPUC Data")
        self.btn_copy_color.setIcon(QIcon(":/icons/loading.png"))
        self.btn_copy_color.setIconSize(icon_size)
        self.btn_copy_color.clicked.connect(self.copy_logs_color)
        self.btn_copy_color.setEnabled(False)

        btn_simplify1 = GrayHoverButton("Simplify 1stPUC Data")
        btn_simplify1.setIcon(QIcon(":/icons/simplify.png"))
        btn_simplify1.setIconSize(icon_size)
        btn_simplify1.clicked.connect(self.simplify1)

        btn_simplify2 = HoverButton("Simplify 2ndPUC Data")
        btn_simplify2.setIcon(QIcon(":/icons/simplify.png"))
        btn_simplify2.setIconSize(icon_size)
        btn_simplify2.clicked.connect(self.simplify2)

        loading_layout = QHBoxLayout()
        loading_layout.addWidget(self.btn_copy_mono)
        loading_layout.addWidget(self.btn_copy_color)
        left_layout.addLayout(loading_layout)

        simplify_layout = QHBoxLayout()
        simplify_layout.addWidget(btn_simplify1)
        simplify_layout.addWidget(btn_simplify2)
        left_layout.addLayout(simplify_layout)

        left_layout.addWidget(QLabel("Enter PID (15 digits) or Short_SN (22 digits) (one per line):"))
        self.text_input = QTextEdit()
        self.text_input.setStyleSheet("""
            QTextEdit {
                background-color: #f0f0f0;
                border: 2px solid #3498db;
                border-radius: 5px;
                padding: 5px;
                font-size: 14px;
            }
            QTextEdit:focus {
                border-color: #2980b9;
                background-color: #ecf0f1;
            }
        """)
        left_layout.addWidget(self.text_input)

        search_clear_layout = QHBoxLayout()  # Thêm dòng này

        search_button = HoverButton("Search EQP")
        search_button.setIcon(QIcon(":/icons/search.png"))
        search_button.setIconSize(icon_size)
        search_button.clicked.connect(self.search)
        search_clear_layout.addWidget(search_button)

        export_csv_button = HoverButton("Export CSV")
        export_csv_button.setIcon(QIcon(":/icons/export.png"))
        export_csv_button.setIconSize(icon_size)
        export_csv_button.clicked.connect(self.export_csv)
        search_clear_layout.addWidget(export_csv_button)

        open_output_button = HoverButton("Open Output")
        open_output_button.setIcon(QIcon(":/icons/open.png"))
        open_output_button.setIconSize(icon_size)
        open_output_button.clicked.connect(self.open_output_folder)
        search_clear_layout.addWidget(open_output_button)

        clear_button = HoverButton("Clear Input Data")
        clear_button.setIcon(QIcon(":/icons/recycle_bin.png"))
        clear_button.setIconSize(icon_size)
        clear_button.clicked.connect(self.clear_data)
        clear_button.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        search_clear_layout.addWidget(clear_button)
        left_layout.addLayout(search_clear_layout)

        right_layout.addWidget(QLabel("Processing Log:"))
        self.processing_log = QTextEdit()
        self.processing_log.setReadOnly(True)
        right_layout.addWidget(self.processing_log)

        content_layout.addWidget(left_frame, 1)
        content_layout.addWidget(right_frame, 1)

        main_layout.addLayout(content_layout)

        self.lbl_author = QLabel("Author: nguyenvanvuong1")
        self.lbl_author.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.lbl_author.setStyleSheet("""
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 5px;
        """)
        main_layout.addWidget(self.lbl_author)

    def center_window(self):
        qr = self.frameGeometry()
        cp = QScreen.availableGeometry(QApplication.primaryScreen()).center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def update_button_states(self):
        enabled = any(checkbox.isChecked() for checkbox in self.line_checkboxes.values())
        self.btn_copy_mono.setEnabled(enabled)
        self.btn_copy_color.setEnabled(enabled)

        selected_lines = [line for line, checkbox in self.line_checkboxes.items() if checkbox.isChecked()]
        if selected_lines:
            self.log_process(f"Selected lines: {', '.join(selected_lines)}")
        else:
            self.log_process("No lines selected")

    def copy_logs_mono(self):
        if not any(checkbox.isChecked() for checkbox in self.line_checkboxes.values()):
            QMessageBox.warning(self, "Warning", "Please select at least one line before copying logs.")
            return
        self.clear_log()
        start_date = self.cal_start.selectedDate().toPyDate()
        end_date = self.cal_end.selectedDate().toPyDate()
        self.log_process(f"Loading 1stPUC logs from {start_date} to {end_date}...")
        selected_lines = [line.split()[0] for line, checkbox in self.line_checkboxes.items() if checkbox.isChecked()]
        copy_logs_mono(start_date, end_date, selected_lines, log_callback=self.log_process)
        self.log_process("1stPUC logs copying process completed.")

    def copy_logs_color(self):
        if not any(checkbox.isChecked() for checkbox in self.line_checkboxes.values()):
            QMessageBox.warning(self, "Warning", "Please select at least one line before copying logs.")
            return
        self.clear_log()
        start_date = self.cal_start.selectedDate().toPyDate()
        end_date = self.cal_end.selectedDate().toPyDate()
        self.log_process(f"Loading 2ndPUC logs from {start_date} to {end_date}...")
        selected_lines = [line.split()[0] for line, checkbox in self.line_checkboxes.items() if checkbox.isChecked()]
        copy_logs_color(start_date, end_date, selected_lines, log_callback=self.log_process)
        self.log_process("2ndPUC logs copying process completed.")

    def simplify1(self):
        self.clear_log()
        self.log_process("Simplifying 1stPUC data...")
        simplify1(log_callback=self.log_process)
        self.log_process("1stPUC data simplified successfully.")

    def simplify2(self):
        self.clear_log()
        self.log_process("Simplifying 2ndPUC data...")
        simplify2(log_callback=self.log_process)
        self.log_process("2ndPUC data simplified successfully.")

    def search(self):
        self.clear_log()
        self.log_process("Searching for PIDs and Short_SNs...")
        csv_file_paths = find_csv_files()
        input_ids = self.text_input.toPlainText().strip().split()
        grouped_data, all_equipments = search_pids(input_ids, csv_file_paths, self.log_process)
        if grouped_data:  # Chỉ kiểm tra grouped_data
            self.create_charts_window(grouped_data, all_equipments)
        else:
            self.log_process("No data found for the given IDs.")

    def create_charts_window(self, grouped_data, all_equipments):
        self.log_process("Creating chart window...")
        chart_window = ChartWindow(grouped_data, all_equipments)
        self.log_process("Chart window created.")
        chart_window.show()
        self.log_process("Chart window displayed.")

    def clear_data(self):
        clear_data(self.log_process)

    def export_csv(self):
        export_csv(self.text_input.toPlainText(), self.log_process)

    def open_output_folder(self):
        open_output_folder()

    def clear_log(self):
        self.processing_log.clear()

    def log_process(self, message):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"[{current_time}] {message}\n"
        self.processing_log.append(log_message)
        QApplication.processEvents()

    def update_start_date(self):
        start_date = self.cal_start.selectedDate()
        self.log_process(f"Start date selected: {start_date.toString('yyyy-MM-dd')}")
        self.cal_end.setMinimumDate(start_date)
        if self.cal_end.selectedDate() < start_date:
            self.cal_end.setSelectedDate(start_date)
        self.cal_end.updateCells()

    def update_end_date(self):
        end_date = self.cal_end.selectedDate()
        self.log_process(f"End date selected: {end_date.toString('yyyy-MM-dd')}")
